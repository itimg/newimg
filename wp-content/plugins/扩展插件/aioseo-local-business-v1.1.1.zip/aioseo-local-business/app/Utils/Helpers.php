<?php
namespace AIOSEO\Plugin\Addon\LocalBusiness\Utils;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Helpers class.
 *
 * @since 1.1.0
 */
class Helpers {
	/**
	 * Returns the global Local SEO options as an object.
	 *
	 * @since 1.1.0
	 *
	 * @return object|false Global Local SEO options as an object.
	 */
	public function getLocalBusinessOptions() {
		return json_decode( wp_json_encode( aioseo()->options->localBusiness->all(), JSON_FORCE_OBJECT ) );
	}

	/**
	 * Returns current permalink structure for this post type.
	 *
	 * @since 1.1.0
	 *
	 * @param  string $postTypeName The post type name.
	 * @param  string $postTypeSlug The post type slug.
	 * @return string               The loaded permastruct or a default if not enabled yet.
	 */
	public function getPermaStructure( $postTypeName, $postTypeSlug ) {
		global $wp_rewrite;

		$structure = $wp_rewrite->get_extra_permastruct( $postTypeName );

		if ( ! $structure ) {
			$structure = '/' . $postTypeSlug . '/%' . $postTypeName . '%/';
		}

		// Account for trailing slashes.
		return user_trailingslashit( $structure );
	}

	/**
	 * Gets the data for vue.
	 *
	 * @since 1.1.0
	 *
	 * @param  array  $data The parent data array to modify.
	 * @param  string $page The current page.
	 * @return array        An array of data.
	 */
	public function getVueData( $data = [], $page = null ) {
		$data['localBusiness'] = [
			'postTypeName'        => aioseoLocalBusiness()->postType->getName(),
			'postTypeEditLink'    => aioseoLocalBusiness()->postType->getEditLink(),
			'postTypeDefaultSlug' => aioseoLocalBusiness()->postType->getDefaultSlug(),
			'postTypeSingleLabel' => aioseoLocalBusiness()->postType->getSingleLabel(),
			'postTypePluralLabel' => aioseoLocalBusiness()->postType->getPluralLabel(),
			'taxonomyName'        => aioseoLocalBusiness()->taxonomy->getName(),
			'taxonomyDefaultSlug' => aioseoLocalBusiness()->taxonomy->getDefaultSlug(),
			'taxonomySingleLabel' => aioseoLocalBusiness()->taxonomy->getSingleLabel(),
			'taxonomyPluralLabel' => aioseoLocalBusiness()->taxonomy->getPluralLabel(),
			'enhancedSearchTest'  => aioseoLocalBusiness()->search->testSearch()
		];

		$post = aioseo()->helpers->getPost();
		if ( ! empty( $post->ID ) && get_post_type( $post->ID ) === aioseoLocalBusiness()->postType->getName() ) {
			$data['currentPost']['localBusinessCategory'] = current( wp_get_object_terms( $post->ID, aioseoLocalBusiness()->taxonomy->getName(), [ 'fields' => 'ids' ] ) ) ?: [];

			// Disable TruSEO.
			$data['options']['advanced']['truSeo'] = false;
		}

		if ( aioseo()->helpers->isScreenBase( 'edit' ) && aioseo()->helpers->isScreenPostType( aioseoLocalBusiness()->postType->getName() ) ) {
			// Disable TruSEO.
			$data['options']['advanced']['truSeo'] = false;
		}

		if ( 'local-seo' === $page ) {
			$cptStructure = aioseoLocalBusiness()->postType->getPermaStructure();
			if ( ! empty( $cptStructure ) and stripos( $cptStructure, aioseoLocalBusiness()->postType->getSlug() ) !== false ) {
				$cptStructure = preg_split( '~\/(' . aioseoLocalBusiness()->postType->getSlug() . ')\/~', $cptStructure, - 1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
				foreach ( $cptStructure as &$cptStructureItem ) {
					if ( aioseoLocalBusiness()->postType->getSlug() === $cptStructureItem ) {
						$cptStructureItem = '{slug}';
					} else {
						$cptStructureItem = '/' . $cptStructureItem;
					}
				}
			}

			$taxStructure = aioseoLocalBusiness()->taxonomy->getPermaStructure();
			if ( ! empty( $taxStructure ) and stripos( $taxStructure, aioseoLocalBusiness()->taxonomy->getSlug() ) !== false ) {
				$taxStructure = preg_split( '~\/(' . aioseoLocalBusiness()->taxonomy->getSlug() . ')\/~', $taxStructure, - 1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
				foreach ( $taxStructure as &$taxStructureItem ) {
					if ( aioseoLocalBusiness()->taxonomy->getSlug() === $taxStructureItem ) {
						$taxStructureItem = '{slug}';
					} else {
						$taxStructureItem = '/' . $taxStructureItem;
					}
				}
			}

			$data['localBusiness']['postTypePermalinkStructure'] = $cptStructure;
			$data['localBusiness']['taxonomyPermalinkStructure'] = $taxStructure;
		}

		return $data;
	}
}