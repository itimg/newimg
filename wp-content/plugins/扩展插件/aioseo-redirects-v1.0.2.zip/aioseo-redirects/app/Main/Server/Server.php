<?php
namespace AIOSEO\Plugin\Addon\Redirects\Main\Server;

use AIOSEO\Plugin\Addon\Redirects\Models;
use AIOSEO\Plugin\Common\Models as CommonModels;

/**
 * Main class to work with server redirects.
 *
 * @since 1.0.0
 */
abstract class Server {
	/**
	 * The URL format.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	protected $urlFormat = '';

	/**
	 * The regex format.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	protected $regexFormat = '';

	/**
	 * File path for the redirects file.
	 *
	 * @since 1.0.0
	 *
	 * @var string|null
	 */
	protected $filePath = null;

	protected $preContent = '';
	protected $postContent = '';

	/**
	 * The intercepted redirect URL to test with.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	private $testInterceptedRedirect = 'aioseo-aioseo-aioseo-test-redirect-intercepted';

	/**
	 * The redirect URL to test with.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	private $testRedirect = 'aioseo-aioseo-aioseo-test-redirects';

	/**
	 * Class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Only do a redirect test when we are doing an ajax request.
		if ( wp_doing_ajax() ) {
			$this->runRedirectsTest();
		}

		$uploadDirectory    = wp_upload_dir();
		$redirectsDirectory = $uploadDirectory['basedir'] . '/aioseo/redirects/';
		$this->filePath     = $redirectsDirectory . '.redirects';
		if ( wp_mkdir_p( $redirectsDirectory ) ) {
			$wpfs = aioseo()->helpers->wpfs();
			if ( ! @$wpfs->exists( $this->filePath ) ) {
				@$wpfs->touch( $this->filePath );
			}

			if ( ! @$wpfs->exists( $redirectsDirectory . 'index.php' ) ) {
				@$wpfs->touch( $redirectsDirectory . 'index.php' );
				@$wpfs->put_contents( $redirectsDirectory . 'index.php', '<?php' . PHP_EOL . '// Silence is golden.' );
			}

			if ( ! @$wpfs->exists( $redirectsDirectory . '.htaccess' ) ) {
				@$wpfs->touch( $redirectsDirectory . '.htaccess' );
				@$wpfs->put_contents( $redirectsDirectory . '.htaccess', "Options -Indexes\ndeny from all" );
			}
		}
	}

	/**
	 * Runs a redirect test in order to verify that server redirects are properly configured.
	 *
	 * @since 4.1.1
	 *
	 * @return void
	 */
	private function runRedirectsTest() {
		$notification = CommonModels\Notification::getNotificationByName( 'redirects-server-missing' );
		if ( 'server' !== aioseoRedirects()->options->main->method ) {
			if ( $notification->exists() ) {
				$notification->delete();
			}
			return;
		}

		$redirectTest = aioseo()->transients->get( 'redirect_test' );
		if ( $redirectTest ) {
			return;
		}

		$redirectTest = [
			'success' => false
		];
		$response = wp_remote_get( home_url( '/' . $this->getTestRedirect() ) );
		$code     = wp_remote_retrieve_response_code( $response );
		if ( 200 === $code ) {
			$redirectTest['success'] = true;
			aioseo()->transients->update( 'redirect_test', $redirectTest, DAY_IN_SECONDS );

			if ( $notification->exists() ) {
				CommonModels\Notification::deleteNotificationByName( 'redirects-server-missing' );
			}

			return;
		}

		aioseo()->transients->update( 'redirect_test', $redirectTest, 10 * MINUTE_IN_SECONDS );

		if ( ! $notification->exists() ) {
			CommonModels\Notification::addNotification( [
				'slug'              => uniqid(),
				'notification_name' => 'redirects-server-missing',
				'title'             => __( 'Server Redirects Missing', 'aioseo-redirects' ),
				'content'           => sprintf(
					// Translators: 1 - The plugin short name ("AIOSEO").
					__( 'Warning: %1$s was unable to detect server level redirects. This probably means the redirects have not been added properly. You may need to reload your server configuration or restart it in order for the redirects to take place.', 'aioseo-redirects' ), // phpcs:ignore Generic.Files.LineLength.MaxExceeded
					AIOSEO_PLUGIN_SHORT_NAME
				),
				'type'              => 'warning',
				'level'             => [ 'all' ],
				'button1_label'     => __( 'Learn More', 'aioseo-redirects' ),
				'button1_action'    => 'https://route#aioseo-redirects:settings',
				'start'             => gmdate( 'Y-m-d H:i:s' )
			] );
		}
	}

	/**
	 * Exports an array of redirects.
	 *
	 * @since 1.0.0
	 *
	 * @param array $redirects The redirects to export.
	 */
	public function export( $redirects = [] ) {
		$content = $this->getAioseoRedirects();
		if ( ! empty( $redirects ) ) {
			foreach ( $redirects as $redirect ) {
				$content .= $this->format( $redirect ) . PHP_EOL;
			}
		}

		// Save the content.
		$this->save( $content );
	}

	/**
	 * Save the redirect file.
	 *
	 * @since 1.0.0
	 *
	 * @param  string  $content The file content that will be saved.
	 * @return void
	 */
	protected function save( $content ) {
		$content = $this->preContent . $content . $this->postContent;

		// Save the actual file.
		$wpfs = aioseo()->helpers->wpfs();
		if ( @$wpfs->is_writable( $this->filePath ) ) {
			@$wpfs->put_contents( $this->filePath, $content );
		}
	}

	/**
	 * Formats a redirect for use in the export.
	 *
	 * @since 1.0.0
	 *
	 * @param  object $redirect The redirect to format.
	 * @return mixed            The formatted redirect.
	 */
	abstract public function format( $redirect );

	/**
	 * Get's a test redirect to use when ensuring users have set it up correctly.
	 *
	 * @since 1.0.0
	 *
	 * @return string The test redirect.
	 */
	abstract protected function getAioseoRedirects();

	/**
	 * Returns the needed format for the redirect.
	 *
	 * @param  boolean $regex Whether or not to use regex.
	 * @return string         The format to use.
	 */
	protected function getFormat( $regex = false ) {
		return $regex ? $this->regexFormat : $this->urlFormat;
	}

	/**
	 * Reset the redirects.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function rewrite() {
		$this->export();

		if ( 'server' === aioseoRedirects()->options->main->method ) {
			$redirects = aioseo()->db->start( 'aioseo_redirects' )
				->where( 'enabled', 1 )
				->run()
				->result();

			$this->export( $redirects );
		}
	}

	/**
	 * Return the test intercepted redirect.
	 *
	 * @since 1.0.0
	 *
	 * @return string The test intercepted redirect.
	 */
	public function getTestInterceptedRedirect() {
		return $this->testInterceptedRedirect;
	}

	/**
	 * Return the test redirect.
	 *
	 * @since 1.0.0
	 *
	 * @return string The test redirect.
	 */
	public function getTestRedirect() {
		return $this->testRedirect;
	}
}