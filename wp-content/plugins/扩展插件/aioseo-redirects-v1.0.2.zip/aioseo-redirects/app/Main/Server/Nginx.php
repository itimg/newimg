<?php
namespace AIOSEO\Plugin\Addon\Redirects\Main\Server;

use AIOSEO\Plugin\Addon\Redirects\Models;

/**
 * Main class to work with server redirects.
 *
 * @since 1.0.0
 */
class Nginx extends Server {
	/**
	 * %1$s is the origin
	 * %2$s is the target
	 * %3$s is the redirect type
	 * %4$s is the optional x-redirect-by filter.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	protected $urlFormat = 'location %1$s { %4$s return %3$s %2$s; }';

	/**
	 * %1$s is the origin
	 * %2$s is the target
	 * %3$s is the redirect type
	 * %4$s is the optional x-redirect-by filter.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	protected $regexFormat = 'location ~ %1$s { %4$s return %3$s %2$s; }';

	/**
	 * Formats a redirect for use in the export.
	 *
	 * @param  object $redirect The redirect to format.
	 * @return string           The formatted redirect.
	 */
	public function format( $redirect ) {
		return sprintf(
			$this->getFormat( $redirect->regex ),
			$redirect->source_url,
			$redirect->target_url,
			$redirect->type,
			$this->addRedirectHeader()
		);
	}

	/**
	 * Adds an X-Redirect-By header if allowed by the filter.
	 *
	 * @since 1.0.0
	 *
	 * @return string The redirect header.
	 */
	private function addRedirectHeader() {
		if ( apply_filters( 'aioseo_redirects_nginx_add_redirect_header', true ) ) {
			return 'add_header X-Redirect-By "AIOSEO";';
		}

		return '';
	}

	/**
	 * Get the test redirect.
	 *
	 * @since 1.0.0
	 *
	 * @return string The test redirect.
	 */
	protected function getAioseoRedirects() {
		return 'location /' . $this->getTestRedirect() . ' { add_header X-Redirect-By "AIOSEO Server Test"; return 301 /' . $this->getTestInterceptedRedirect() . '; }' . PHP_EOL;
	}
}