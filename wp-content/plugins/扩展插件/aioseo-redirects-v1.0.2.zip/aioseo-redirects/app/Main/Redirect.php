<?php
namespace AIOSEO\Plugin\Addon\Redirects\Main;

use AIOSEO\Plugin\Addon\Redirects\Models;
use AIOSEO\Plugin\Addon\Redirects\Utils;

/**
 * Main class to run our redirects.
 *
 * @since 1.0.0
 */
class Redirect {
	/**
	 * Matched redirect.
	 *
	 * @since 1.0.0
	 *
	 * @var boolean
	 */
	private $matched = false;

	/**
	 * The target redirect URL.
	 *
	 * @since 1.0.0
	 *
	 * @var string|null
	 */
	private $redirectUrl = null;

	/**
	 * The target redirect code.
	 *
	 * @since 1.0.0
	 *
	 * @var integer
	 */
	private $redirectCode = 0;

	/**
	 * Class conststructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Schedule clearing of logs.
		add_action( 'init', [ $this, 'scheduleClearing' ], 2 );

		if ( is_admin() ) {
			return;
		}

		// Log 404's and intercept our test redirect.
		add_action( 'template_redirect', [ $this, 'templateRedirect' ] );

		// Log external redirect agents.
		add_filter( 'x_redirect_by', [ $this, 'logExternalRedirect' ], 1000 );

		// If we are using server level redirects, return early.
		if ( 'server' === aioseoRedirects()->options->main->method ) {
			return;
		}

		// The main redirect loop.
		add_action( 'init', [ $this, 'init' ] );

		// Redirect HTTP headers and server-specific overrides.
		add_filter( 'wp_redirect', [ $this, 'wpRedirect' ], 1, 2 );
	}

	/**
	 * Redirection 'main loop'. Checks the currently requested URL against the database and perform a redirect, if necessary.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function init() {
		if ( is_admin() || $this->matched ) {
			return;
		}

		$requestUrl = Utils\Request::getRequestUrl();
		if ( $this->isProtectedUrl( $requestUrl ) ) {
			return;
		}

		$newRequestUrl     = wp_parse_url( $requestUrl );
		$queryString       = ! empty( $newRequestUrl['query'] ) ? $newRequestUrl['query'] : false;
		$requestUrlNoQuery = ! empty( $newRequestUrl['path'] ) ? $newRequestUrl['path'] : '/';
		$requestUrlHash    = sha1( untrailingslashit( $requestUrlNoQuery ) );

		$cacheName = 'aioseo_redirects_url_' . $requestUrlHash;
		$redirects = aioseo()->transients->get( $cacheName );
		if ( ! $redirects ) {
			$redirects = aioseo()->db->start( 'aioseo_redirects' )
				->whereRaw( 'source_url_match_hash = "' . $requestUrlHash . '"' )
				->where( 'enabled', 1 )
				->orderBy( 'id DESC' )
				->run()
				->result();

			if ( empty( $redirects ) ) {
				$redirects = aioseo()->db->start( 'aioseo_redirects' )
					->whereRaw( 'source_url_match_hash = "' . sha1( 'regex' ) . '"' )
					->where( 'enabled', 1 )
					->orderBy( 'id DESC' )
					->run()
					->result();
			}

			aioseo()->transients->update( $cacheName, $redirects, DAY_IN_SECONDS );
		}

		// Run through the list until one fires.
		foreach ( $redirects as $redirect ) {
			$formattedFromUrl = trim( $redirect->source_url );
			$formattedToUrl   = trim( $redirect->target_url );
			if ( $redirect->ignore_slash ) {
				if ( '/' !== $redirect->target_url ) {
					$formattedFromUrl = preg_replace( '@/$@', '', $formattedFromUrl );
				}

				if ( '/' !== $formattedFromUrl ) {
					$formattedToUrl = preg_replace( '@/$@', '', $formattedToUrl );
				}
			}

			// If we have an exact match, let's get out of here or the user will be in a redirect loop.
			if ( $formattedFromUrl === $formattedToUrl ) {
				$this->matched = true;
				continue;
			}

			$formattedFromUrl = Utils\Request::formatSourceUrl( $formattedFromUrl );
			$formattedToUrl   = Utils\Request::formatTargetUrl( $formattedToUrl );
			if ( $redirect->ignore_case ) {
				$formattedFromUrl = aioseo()->helpers->toLowercase( $formattedFromUrl );
				$formattedToUrl   = aioseo()->helpers->toLowercase( $formattedToUrl );
			}

			$compareUrlRequest = $requestUrlNoQuery;
			if ( $redirect->regex ) {
				$compareUrlRequest = $requestUrl;
			}

			$queryStringNew = [];
			if (
				(
					'utm' === $redirect->query_param ||
					'exact' === $redirect->query_param
				) &&
				0 < strlen( $queryString )
			) {
				$queryStringArray = explode( '&', $queryString );

				foreach ( $queryStringArray as $value ) {
					if ( 'exact' === $redirect->query_param ) {
						$queryStringNew[] = $value;
						continue;
					}

					$expKey = explode( '_', $value );
					if ( 'utm' === $expKey[0] ) {
						$queryStringNew[] = $value;
					}
				}

				$queryString = implode( '&', $queryStringNew );
			}

			if ( 'exact' === $redirect->query_param ) {
				$formattedFromUrlArray            = explode( '?', $formattedFromUrl );
				$formattedFromUrlQueryString      = ( isset( $formattedFromUrlArray[1] ) ) ? $formattedFromUrlArray[1] : false;
				$formattedFromUrlQueryStringArray = explode( '&', $formattedFromUrlQueryString );

				// If we can't find this query string inside the array, we need to skip this redirect.
				foreach ( $formattedFromUrlQueryStringArray as $value ) {
					if ( empty( $value ) && empty( $queryStringNew ) ) {
						continue;
					}

					if ( ! in_array( $value, $queryStringNew, true ) ) {
						continue 2;
					}
				}

				// Now that we have computed the value, we don't need the query string, so let's reset.
				$queryString = '';
			}

			$to = ( strlen( $queryString ) > 0 && 'ignore' !== $redirect->query_param ) ? $formattedToUrl . '?' . $queryString : $formattedToUrl;

			if ( $redirect->regex ) {
				$target  = rtrim( trim( $compareUrlRequest ), '/' );
				$pattern = $this->formatPattern( stripslashes( $formattedFromUrl ), $redirect->ignore_case );

				if ( ! preg_match( $pattern, $target ) ) {
					continue;
				}

				$to = @preg_replace( $pattern, $to, $target );
				if ( is_null( $to ) ) {
					$to = $target;
				}

				// Space encode the target.
				$split = explode( '?', $to );
				$to    = str_replace( ' ', '%20', $to );
				if ( count( $split ) === 2 ) {
					$to = implode( '?', [ str_replace( ' ', '%20', $split[0] ), str_replace( ' ', '+', $split[1] ) ] );
				}
			}

			$this->matched = $redirect->id;

			// Save a hit.
			$hits = aioseo()->db->start( 'aioseo_redirects_hits' )
				->where( 'redirect_id', $redirect->id )
				->run()
				->model( 'AIOSEO\\Plugin\\Addon\\Redirects\\Models\\RedirectsHit' );

			if ( ! $hits->exists() ) {
				$hits->redirect_id = $redirect->id;
				$hits->count       = 0;
			}

			$hits->count += 1;
			$hits->save();

			$this->redirectUrl  = $to;
			$this->redirectCode = $redirect->type;

			$this->logRedirect( $this->redirectCode, 'aioseo', $redirect->id );

			if ( wp_redirect( $to, $redirect->type, 'AIOSEO' ) ) {
				global $wp_version;
				if ( version_compare( $wp_version, '5.1', '<' ) ) {
					header( 'X-Redirect-Agent: AIOSEO' );
				}
				die;
			}
		}
	}

	/**
	 * Schedule clearing of the logs.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function scheduleClearing() {
		$actions = [];
		$preActions = [
			'log404'    => [
				'action' => 'aioseo_redirects_clear_404_logs',
				'method' => 'clear404Logs'
			],
			'redirects' => [
				'action' => 'aioseo_redirects_clear_logs',
				'method' => 'clearRedirectLogs'
			]
		];

		foreach ( $preActions as $key => $data ) {
			$optionLength = json_decode( aioseoRedirects()->options->logs->{ $key }->length )->value;
			if (
				aioseoRedirects()->options->logs->{ $key }->enabled &&
				'forever' !== $optionLength
			) {
				$length = WEEK_IN_SECONDS;
				if ( 'hour' === $optionLength ) {
					$length = HOUR_IN_SECONDS;
				} elseif ( 'day' === $optionLength ) {
					$length = DAY_IN_SECONDS;
				}
				$actions[ $data['action'] ] = [
					'length' => $length,
					'method' => $data['method']
				];

				continue;
			}

			$this->unscheduleClearing( $data['action'] );
		}

		foreach ( $actions as $action => $data ) {
			try {
				// Register the action handler.
				add_action( $action, [ $this, $data['method'] ] );

				if ( ! as_next_scheduled_action( $action ) ) {
					as_schedule_recurring_action( time() + 60, $data['length'], $action, [], 'aioseo' );
				}
			} catch ( \Exception $e ) {
				// Do nothing.
			}
		}
	}

	/**
	 * Unschedule the clearing of the log.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $action The action to unschedule.
	 * @return void
	 */
	public function unscheduleClearing( $action ) {
		// If we made it this far, we don't want the action scheduled, so let's unschedule it.
		try {
			if ( as_next_scheduled_action( $action ) ) {
				as_unschedule_action( $action, [], 'aioseo' );
			}
		} catch ( \Exception $e ) {
			// Do nothing.
		}
	}

	/**
	 * Clears the 404 logs.
	 *
	 * @return void
	 */
	public function clear404Logs() {
		$optionLength = json_decode( aioseoRedirects()->options->logs->log404->length )->value;
		if ( 'forever' === $optionLength ) {
			return;
		}

		$date = date( 'Y-m-d H:i:s', strtotime( '-1 ' . $optionLength ) );
		aioseo()->db
			->delete( 'aioseo_redirects_404_logs' )
			->where( 'created <', $date )
			->run();
	}

	/**
	 * Clears the redirect logs.
	 *
	 * @return void
	 */
	public function clearRedirectLogs() {
		$optionLength = json_decode( aioseoRedirects()->options->logs->redirects->length )->value;
		if ( 'forever' === $optionLength ) {
			return;
		}

		$date = date( 'Y-m-d H:i:s', strtotime( '-1 ' . $optionLength ) );
		aioseo()->db
			->delete( 'aioseo_redirects_logs' )
			->where( 'created <', $date )
			->run();
	}

	/**
	 * Perform any pre-redirect processing, such as logging and header fixing.
	 *
	 * @since 1.0.0
	 *
	 * @param  string  $url    The target URL.
	 * @param  integer $status HTTP status.
	 * @return string          The target URL.
	 */
	public function wpRedirect( $url, $status = 302 ) {
		// These are set early on so when other filters run, we have access to it.
		$this->redirectUrl  = $url;
		$this->redirectCode = $status;

		global $is_IIS;

		if ( $is_IIS ) {
			header( "Refresh: 0;url=$url" );
		}

		if ( 301 === $status && php_sapi_name() === 'cgi-fcgi' ) {
			$serversToCheck = [ 'lighttpd', 'nginx' ];

			foreach ( $serversToCheck as $name ) {
				if (
					isset( $_SERVER['SERVER_SOFTWARE'] ) &&
					false !== stripos( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ), $name ) // phpcs:ignore HM.Security.ValidatedSanitizedInput.InputNotSanitized
				) {
					status_header( $status );
					header( "Location: $url" );
					exit( 0 );
				}
			}
		}

		if ( 307 === intval( $status, 10 ) ) {
			status_header( $status );
			nocache_headers();
			return $url;
		}

		if ( ! aioseoRedirects()->options->cache->httpHeader->enabled ) {
			// No cache - just use WP function.
			nocache_headers();
		} else {
			if (
				! headers_sent() &&
				'forever' !== aioseoRedirects()->options->cache->httpHeader->length &&
				301 === intval( $status, 10 )
			) {
				// Custom cache.
				$cacheTime = 1;
				switch ( aioseoRedirects()->options->cache->httpHeader->length ) {
					case 'day':
						$cacheTime = 24;
					case 'week':
						$cacheTime = 168;
					case 'hour':
					default:
						break;
				}
				header( 'Expires: ' . gmdate( 'D, d M Y H:i:s T', time() + $cacheTime * 60 * 60 ) );
				header( 'Cache-Control: max-age=' . $cacheTime * 60 * 60 );
			}
		}

		status_header( $status );
		return $url;
	}

	/**
	 * Logs a redirect.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $agent Redirect agent.
	 * @return string        Redirect agent.
	 */
	public function logExternalRedirect( $agent ) {
		// Have we already redirected?
		if ( $this->matched || 'aioseo' === $agent ) {
			return $agent;
		}

		if (
			! aioseoRedirects()->options->logs->external ||
			! aioseoRedirects()->options->logs->redirects->enabled
		) {
			return $agent;
		}

		$redirectBy = $agent ? strtolower( substr( $agent, 0, 50 ) ) : 'wordpress'; // phpcs:ignore WordPress.WP.CapitalPDangit.Misspelled
		$this->logRedirect( $this->redirectCode, $redirectBy );

		return $agent;
	}

	/**
	 * Intercept the request and parse if needed.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function templateRedirect() {
		global $wp;

		$request      = $wp->request;
		$testRedirect = aioseoRedirects()->server->getTestInterceptedRedirect();
		if ( $testRedirect === $request ) {
			// If this is our redirect, send a 200 response with a user-friendly message.
			wp_die(
				// Translators: 1 - The plugin short name ("AIOSEO").
				sprintf( esc_html__( 'It looks like %1$s server-level redirects are configured properly and working as expected.', 'aioseo-redirects' ), esc_html( AIOSEO_PLUGIN_SHORT_NAME ) ),
				esc_html__( 'Server Redirect Test', 'aioseo-redirects' ),
				[ 'response' => 200 ]
			);
		}

		$this->log404();
	}

	/**
	 * WordPress 'template_redirect' hook. Used to check for 404s.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function log404() {
		if ( ! is_404() || $this->matched ) {
			return;
		}

		if ( ! aioseoRedirects()->options->logs->log404->enabled ) {
			return;
		}

		$this->logRedirect( 404 );
	}

	/**
	 * Logs the redirects.
	 *
	 * @since 1.0.0
	 *
	 * @param  integer $status     The HTTP status code.
	 * @param  string  $redirectBy The redirect agent.
	 * @param  integer $redirectId The redirect ID.
	 * @return void
	 */
	private function logRedirect( $status, $redirectBy = null, $redirectId = null ) {
		$ip = null;
		if ( aioseoRedirects()->options->logs->ipAddress->enabled ) {
			$ip      = Utils\Request::getIp();
			$ipLevel = json_decode( aioseoRedirects()->options->logs->ipAddress->level )->value;
			if ( 'full' !== $ipLevel ) {
				$ip = Utils\Request::maskIp( $ip );
			}
		}

		$data = [
			'url'            => Utils\Request::getRequestUrl(),
			'domain'         => Utils\Request::getServer(),
			'sent_to'        => $this->redirectUrl,
			'agent'          => Utils\Request::getUserAgent(),
			'referrer'       => Utils\Request::getReferrer(),
			'http_code'      => $status,
			'request_method' => Utils\Request::getRequestMethod(),
			'ip'             => $ip,
			'request_data'   => [
				'source' => array_values( $this->getRedirectSource() )
			]
		];

		if ( $redirectId ) {
			$data['redirect_id'] = $redirectId;
		}

		if ( $redirectBy ) {
			$data['redirect_by'] = $redirectBy;
		}

		if ( aioseoRedirects()->options->logs->httpHeader ) {
			$data['request_data']['headers'] = Utils\Request::getRequestHeaders();
		}

		$log = 404 === $status ? new Models\Redirects404Log() : new Models\RedirectsLog();
		$log->set( $data );
		$log->save();
	}

	/**
	 * Get a 'source' for a redirect by digging through the backtrace.
	 *
	 * @since 1.0.0
	 *
	 * @return string The redirect source.
	 */
	private function getRedirectSource() {
		$ignore = [
			'WP_Hook',
			'template-loader.php',
			'wp-blog-header.php',
		];

		// phpcs:ignore
		$source = wp_debug_backtrace_summary( null, 5, false );

		return array_filter( $source, function( $item ) use ( $ignore ) {
			foreach ( $ignore as $ignore_item ) {
				if ( strpos( $item, $ignore_item ) !== false ) {
					return false;
				}
			}

			return true;
		} );
	}

	/**
	 * Formats the regex pattern that we are using.
	 *
	 * @since 1.0.0
	 *
	 * @param  string  $pattern    The pattern to format.
	 * @param  boolean $ignoreCase Whether or not to ignore case.
	 * @return string              The formatted pattern.
	 */
	private function formatPattern( $pattern, $ignoreCase ) {
		$pattern = str_replace( '.*', '*', $pattern );

		$pattern = preg_replace_callback( '/[\\\\^$.[\\]|()?*+{}\\-\\/]/', function ( $matches ) {
			switch ( $matches[0] ) {
				case '*':
					return '.*';
				case '/':
					return '\/';
				default:
					return $matches[0];
			}
		}, $pattern );

		$pattern = str_replace( '\/^', '^', $pattern );
		$pattern = str_replace( '\\\'', '\'', $pattern );

		$pattern = '/' . $pattern . '$/';
		if ( $ignoreCase ) {
			$pattern .= 'i';
		};

		return $pattern;
	}

	private function isProtectedUrl( $url ) {
		$rest = wp_parse_url( get_rest_url() );
		$rest_api = $rest['path'] . ( isset( $rest['query'] ) ? '?' . $rest['query'] : '' );

		if ( substr( $url, 0, strlen( $rest_api ) ) === $rest_api ) {
			// Never redirect the REST API.
			return true;
		}

		return false;
	}
}