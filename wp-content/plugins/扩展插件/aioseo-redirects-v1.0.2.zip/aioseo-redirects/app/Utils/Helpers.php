<?php
namespace AIOSEO\Plugin\Addon\Redirects\Utils;

use AIOSEO\Plugin\Addon\Redirects\Models;

/**
 * Contains helper functions
 *
 * @since 1.0.0
 */
class Helpers {
	/**
	 * Gets the data for vue.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $page The current page.
	 * @return array        An array of data.
	 */
	public function getVueData( $data = [], $page = null ) {
		if ( 'redirects' === $page ) {
			return $this->getRedirectsPageData( $data );
		}

		if ( 'tools' === $page ) {
			return $this->getToolsPageData( $data );
		}

		return $data;
	}

	/**
	 * Get redirects page data.
	 *
	 * @since 1.0.0
	 *
	 * @param  array $data The data array.
	 * @return array       The modified data array.
	 */
	private function getRedirectsPageData( $data ) {
		// Get the total number of results.
		$total     = aioseo()->db->start( 'aioseo_redirects' )->count();
		$total404  = aioseo()->db->start( 'aioseo_redirects_404_logs' )->groupBy( 'url' )->count();
		$totalLogs = aioseo()->db->start( 'aioseo_redirects_logs' )->groupBy( 'url' )->count();

		// Inject our vue data into this page.
		$wpUploadDir       = wp_upload_dir();
		$data['redirects'] = [
			'options'   => aioseoRedirects()->options->all(),
			'rows'      => array_values(
				aioseo()->db->start( 'aioseo_redirects' )
					->orderBy( 'id DESC' )
					->limit( 20, 0 )
					->run()
					->models( 'AIOSEO\\Plugin\\Addon\\Redirects\\Models\\Redirect', null, true )
			),
			'logs404'   => aioseo()->db->start( 'aioseo_redirects_404_logs as `l1`' )
				->select( 'l1.url as id, l1.url, l2.hits, l1.created as last_accessed, l1.request_data, l1.ip' )
				->join(
					'(SELECT MAX(id) as id, count(*) as hits FROM ' . aioseo()->db->db->prefix . 'aioseo_redirects_404_logs GROUP BY `url` LIMIT 0, 20 ) as `l2`',
					'`l2`.`id` = `l1`.`id`',
					'',
					true
				)
				->orderBy( 'last_accessed DESC' )
				->limit( 20, 0 )
				->run()
				->result(),
			'logs'      => aioseo()->db->start( 'aioseo_redirects_logs as `l1`' )
				->select( 'l1.url as id, l1.url, l2.hits, l1.created as last_accessed, l1.request_data, l1.ip' )
				->join(
					'(SELECT MAX(id) as id, count(*) as hits FROM ' . aioseo()->db->db->prefix . 'aioseo_redirects_logs GROUP BY `url` LIMIT 0, 20 ) as `l2`',
					'`l2`.`id` = `l1`.`id`',
					'',
					true
				)
				->orderBy( 'last_accessed DESC' )
				->run()
				->result(),
			'filters'   => [
				[
					'slug'   => 'all',
					'name'   => __( 'All', 'aioseo-redirect-manager' ),
					'count'  => $total,
					'active' => true
				],
				[
					'slug'   => 'enabled',
					'name'   => __( 'Enabled', 'aioseo-redirect-manager' ),
					'count'  => aioseo()->db->start( 'aioseo_redirects' )->where( 'enabled', 1 )->count(),
					'active' => false
				],
				[
					'slug'   => 'disabled',
					'name'   => __( 'Disabled', 'aioseo-redirect-manager' ),
					'count'  => aioseo()->db->start( 'aioseo_redirects' )->where( 'enabled', 0 )->count(),
					'active' => false
				]
			],
			'totals'    => [
				'total404' => [
					'total' => $total404,
					'pages' => ceil( $total404 / 20 ),
					'page'  => 1
				],
				'logs'     => [
					'total' => $totalLogs,
					'pages' => ceil( $totalLogs / 20 ),
					'page'  => 1
				],
				'main'     => [
					'total' => $total,
					'pages' => ceil( $total / 20 ),
					'page'  => 1
				]
			],
			'path'      => $wpUploadDir['basedir'] . '/aioseo/redirects/.redirects',
			'importers' => aioseoRedirects()->importExport->plugins()
		];

		$data['data']['server'] = [
			'apache' => aioseo()->helpers->isApache(),
			'nginx'  => aioseo()->helpers->isNginx()
		];

		// Verify that server redirects are enabled.
		$redirectTest = aioseo()->transients->get( 'redirect_test' );
		$data['data']['server']['serverRedirects'] = ! empty( $redirectTest['success'] );

		return $data;
	}

	/**
	 * Get tools page data.
	 *
	 * @since 1.0.0
	 *
	 * @param  array $data The data array.
	 * @return array       The modified data array.
	 */
	private function getToolsPageData( $data ) {
		$data['data']['logSizes']['logs404']      = aioseo()->helpers->convertFileSize( aioseo()->db->getTableSize( 'aioseo_redirects_404_logs' ) );
		$data['data']['logSizes']['redirectLogs'] = aioseo()->helpers->convertFileSize( aioseo()->db->getTableSize( 'aioseo_redirects_logs' ) );

		return $data;
	}
}